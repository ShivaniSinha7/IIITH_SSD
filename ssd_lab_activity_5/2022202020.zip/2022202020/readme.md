##index.html
In index.html we have created a login form which take username and password and on on clicking submit button get redirected to studentRecords.html

##studentRecords.html

In studentsRecords.html file initially there is empty students record table and on clicking Add New button new record is created and on clicking delete last record button it delete last record


##style.css
Used CSS to design both html files

